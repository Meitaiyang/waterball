from showdown import Showdown

if __name__ == "__main__":
    showdown = Showdown()
    showdown.start()
    showdown.end()
