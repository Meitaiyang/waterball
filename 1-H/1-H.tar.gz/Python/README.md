# The challenge of 1-H
## USAGE
- please run `python main.py` to start the program